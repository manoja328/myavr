#include "lcd.h"


#define one 0x16 
#define two 0x1E 
#define three 0x26 
#define aaa 0x1c 
#define bbb 0x32
#define ccc 0x21



volatile unsigned char _bitCount;
volatile unsigned char data;
volatile unsigned char done=0;

void keyboardInit( void )
{
	DDRD|=(1<<PD3) | (1<<PD4);;	//int1(pd3--5) and pd4(6) pin for clock and data 
	
	_bitCount = 11;		// Get 11 bits from the keyboard.
	MCUCR = 0x0C;		// Setup INT0 for the falling edge.
	GICR= 0x40;		// Enable INT0 interrupt

}



ISR( INT1_vect )
{
	
	done=0;
		
	_bitCount = _bitCount - 1  ;	
	
	if ( _bitCount > 2 && _bitCount < 10  )
		{
			data = ( data >> 1 );	// Shift the data over.
			if ( PIND & (1<<PD4) )
				data |= 0x80;	// Add a bit if it is a one.
		}

	
	
	else if  (_bitCount==1)
	{
		done=1;
		_bitCount = 11;		
		
	}
	
		
	
}




int main( void )
{
	initLCD();
	
	keyboardInit( );
	
	
	LCD_goto(1,0);
	lcd_puts("START KEYBOARD!");

	
	
	sei();

	while( 1 )
	{
		if (data != 0 )
		{
			switch ( data )
			{
				case one:
				{
					LCD_goto(2,0);
					lcd_puts("ONE");
					break;
				}
				case two:
				{
					LCD_goto(2,0);
					lcd_puts("TWO");
					break;
				}
				case three:
				{
					LCD_goto(2,0);
					lcd_puts("THREE");
					break;
				}
				case aaa:
				{
					LCD_goto(2,0);
					lcd_puts("A");
					break;
				}
				case bbb:
				{
					LCD_goto(2,0);
					lcd_puts("B");
					break;
				}
				default:
				{
					LCD_goto(2,6);
					LCD_num(data);
				}
			}
		}
	}
	return 0;
}
